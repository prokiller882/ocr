"""
PP-OCRv6 纯 ONNX Runtime 推理引擎。
零 PaddlePaddle 依赖，仅需 onnxruntime + opencv + numpy + pyclipper。
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np
import onnxruntime as ort
import pyclipper

# ---------------------------------------------------------------------------
# 异常类型
# ---------------------------------------------------------------------------


class PPOCRv6Error(Exception):
    """PPOCRv6 库基础异常。"""


class ModelLoadError(PPOCRv6Error):
    """ONNX 模型加载失败。"""


class InputError(PPOCRv6Error):
    """输入数据不合法。"""


# ---------------------------------------------------------------------------
# 公共类型
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class OCRResult:
    """单条 OCR 识别结果。"""
    text: str
    score: float
    box: List[List[int]]


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------


def _order_minarea_box_points(contour: np.ndarray) -> Tuple[List[np.ndarray], float]:
    """minAreaRect → 四点排序 [左上, 右上, 右下, 左下] + 短边长"""
    rrect = cv2.minAreaRect(contour)
    pts = sorted(cv2.boxPoints(rrect), key=lambda p: p[0])
    tl, bl = (0, 1) if pts[1][1] > pts[0][1] else (1, 0)
    tr, br = (2, 3) if pts[3][1] > pts[2][1] else (3, 2)
    return [pts[tl], pts[tr], pts[br], pts[bl]], min(rrect[1])


def sort_quad_boxes(boxes: np.ndarray) -> np.ndarray:
    """按阅读顺序排序文本框（从上到下、从左到右）"""
    if len(boxes) <= 1:
        return boxes
    items = sorted(boxes, key=lambda b: (b[0][1], b[0][0]))
    n = len(items)
    for i in range(n - 1):
        for j in range(i, -1, -1):
            if abs(items[j + 1][0][1] - items[j][0][1]) < 10 and (
                items[j + 1][0][0] < items[j][0][0]
            ):
                items[j], items[j + 1] = items[j + 1], items[j]
            else:
                break
    return np.array(items, dtype=boxes.dtype)


# ============================================================
# 检测预处理
# ============================================================


class DetPreProcess:
    """检测预处理：Resize(32对齐) → ImageNet归一化 → CHW → batch"""

    _VALID_LIMIT_TYPES = ("min", "max")

    def __init__(self, limit_side_len: int = 64, limit_type: str = "min",
                 max_side_limit: int = 4000) -> None:
        if limit_type not in self._VALID_LIMIT_TYPES:
            raise InputError(
                f"limit_type must be one of {self._VALID_LIMIT_TYPES}, got {limit_type!r}"
            )
        self.limit_side_len = limit_side_len
        self.limit_type = limit_type
        self.max_side_limit = max_side_limit
        self._scale = np.float32(1.0 / 255.0)
        self._mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        self._std = np.array([0.229, 0.224, 0.225], dtype=np.float32)

    @staticmethod
    def _validate_image(img: np.ndarray, name: str = "image") -> None:
        """校验输入是否为合法的 BGR 三通道图像。"""
        if img is None or not isinstance(img, np.ndarray):
            raise InputError(f"{name} must be a numpy ndarray")
        if img.ndim == 2:
            raise InputError(
                f"{name} is a single-channel (grayscale) image. "
                "PPOCRv6 requires a 3-channel BGR image."
            )
        if img.ndim != 3 or img.shape[2] != 3:
            raise InputError(
                f"{name} must be a 3-channel BGR image, got shape {img.shape}"
            )
        if img.shape[0] < 32 or img.shape[1] < 32:
            raise InputError(
                f"{name} is too small ({img.shape[0]}x{img.shape[1]}). "
                "Image must be at least 32x32 pixels."
            )

    def _resize(self, img: np.ndarray) -> Tuple[np.ndarray, float, float]:
        h, w = img.shape[:2]
        limit = self.limit_side_len
        if self.limit_type == "max":
            ratio = float(limit) / max(h, w) if max(h, w) > limit else 1.0
        else:
            ratio = float(limit) / min(h, w) if min(h, w) < limit else 1.0
        rh, rw = int(h * ratio), int(w * ratio)
        if max(rh, rw) > self.max_side_limit:
            ratio = float(self.max_side_limit) / max(rh, rw)
            rh, rw = int(rh * ratio), int(rw * ratio)
        rh = max(int(round(rh / 32) * 32), 32)
        rw = max(int(round(rw / 32) * 32), 32)
        if rh == h and rw == w:
            return img, 1.0, 1.0
        return cv2.resize(img, (rw, rh)), rh / float(h), rw / float(w)

    def __call__(self, img: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        self._validate_image(img)
        src_h, src_w = img.shape[:2]
        resized, ratio_h, ratio_w = self._resize(img)
        norm = (resized.astype(np.float32, copy=False) * self._scale - self._mean) / self._std
        chw = np.transpose(norm, (2, 0, 1))
        tensor = chw[np.newaxis, ...].astype(np.float32, copy=False)
        shape = np.array([src_h, src_w, ratio_h, ratio_w], dtype=np.float32)
        return tensor, shape


# ============================================================
# 检测后处理 (DB)
# ============================================================


class DBPostProcess:
    """DB 后处理：概率图 → 二值化 → findContours → unclip → 过滤"""

    def __init__(self, thresh: float = 0.3, box_thresh: float = 0.6,
                 unclip_ratio: float = 1.5, max_candidates: int = 1000,
                 min_size: int = 3) -> None:
        self.thresh = thresh
        self.box_thresh = box_thresh
        self.unclip_ratio = unclip_ratio
        self.max_candidates = max_candidates
        self.min_size = min_size

    @staticmethod
    def _box_score(bitmap: np.ndarray, points: np.ndarray) -> float:
        h, w = bitmap.shape[:2]
        box = points.astype(np.float32, copy=True)
        xmin = int(np.clip(np.floor(box[:, 0].min()), 0, w - 1))
        xmax = int(np.clip(np.ceil(box[:, 0].max()), 0, w - 1))
        ymin = int(np.clip(np.floor(box[:, 1].min()), 0, h - 1))
        ymax = int(np.clip(np.ceil(box[:, 1].max()), 0, h - 1))
        mask = np.zeros((ymax - ymin + 1, xmax - xmin + 1), dtype=np.uint8)
        box[:, 0] -= xmin
        box[:, 1] -= ymin
        cv2.fillPoly(mask, box.reshape(1, -1, 2).astype(np.int32), 1)
        return float(cv2.mean(bitmap[ymin:ymax + 1, xmin:xmax + 1], mask)[0])

    def _unclip(self, box: np.ndarray) -> np.ndarray:
        area = cv2.contourArea(box)
        length = cv2.arcLength(box, closed=True)
        if length < 1e-6:
            return box  # 退化多边形，无法扩展
        distance = area * self.unclip_ratio / length
        if distance < 1e-6:
            return box  # 无需扩展
        po = pyclipper.PyclipperOffset()
        po.AddPath(box.astype(np.int32), pyclipper.JT_ROUND, pyclipper.ET_CLOSEDPOLYGON)
        try:
            paths = po.Execute(distance)
            if not paths:
                return box
            return np.asarray(paths[0])
        except pyclipper.PyclipperException:
            return box

    def _extract_boxes(self, prob: np.ndarray, bitmap: np.ndarray,
                       dst_w: int, dst_h: int) -> Tuple[np.ndarray, List[float]]:
        outs = cv2.findContours((bitmap * 255).astype(np.uint8),
                                cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        contours = outs[1] if len(outs) == 3 else outs[0]
        ws, hs = dst_w / bitmap.shape[1], dst_h / bitmap.shape[0]
        boxes, scores = [], []
        for contour in contours[:self.max_candidates]:
            pts, sside = _order_minarea_box_points(contour)
            if sside < self.min_size:
                continue
            pts_np = np.array(pts, dtype=np.float32)
            score = self._box_score(prob, pts_np.reshape(-1, 2))
            if score < self.box_thresh:
                continue
            expanded = self._unclip(pts_np).reshape(-1, 1, 2)
            expanded_pts, sside2 = _order_minarea_box_points(expanded)
            if sside2 < self.min_size + 2:
                continue
            box = np.array(expanded_pts, dtype=np.float32)
            box[:, 0] = np.clip(np.round(box[:, 0] * ws), 0, dst_w)
            box[:, 1] = np.clip(np.round(box[:, 1] * hs), 0, dst_h)
            boxes.append(box.astype(np.int16))
            scores.append(score)
        if not boxes:
            return np.empty((0, 4, 2), dtype=np.int16), []
        return np.stack(boxes, axis=0), scores

    def __call__(self, pred: np.ndarray, img_shape: np.ndarray
                 ) -> Tuple[np.ndarray, List[float]]:
        if pred.ndim != 4 or pred.shape[0] != 1 or pred.shape[1] != 1:
            raise InputError(
                f"Detection model output must have shape (1, 1, H, W), "
                f"got {pred.shape}"
            )
        prob_map = pred[0, 0, :, :]
        if prob_map.size == 0:
            return np.empty((0, 4, 2), dtype=np.int16), []
        segmentation = prob_map > self.thresh
        return self._extract_boxes(prob_map, segmentation,
                                   int(img_shape[1]), int(img_shape[0]))


# ============================================================
# 文本区域裁剪
# ============================================================


def _rotate_crop_image(img: np.ndarray, points: np.ndarray) -> Optional[np.ndarray]:
    """透视变换裁剪文本区域，竖排自动转横"""
    pts = points.astype(np.float32)
    crop_w = int(max(np.linalg.norm(pts[0] - pts[1]), np.linalg.norm(pts[2] - pts[3])))
    crop_h = int(max(np.linalg.norm(pts[0] - pts[3]), np.linalg.norm(pts[1] - pts[2])))
    if crop_w < 1 or crop_h < 1:
        return None
    dst_pts = np.float32([[0, 0], [crop_w, 0], [crop_w, crop_h], [0, crop_h]])
    try:
        M = cv2.getPerspectiveTransform(pts, dst_pts)
    except cv2.error:
        return None
    cropped = cv2.warpPerspective(img, M, (crop_w, crop_h),
                                  borderMode=cv2.BORDER_REPLICATE,
                                  flags=cv2.INTER_CUBIC)
    if cropped.shape[0] / cropped.shape[1] >= 1.5:
        cropped = np.rot90(cropped)
    return cropped


def crop_by_polys(img: np.ndarray, dt_polys: np.ndarray) -> List[Optional[np.ndarray]]:
    """批量裁剪文本区域"""
    if len(dt_polys) == 0:
        return []
    results = []
    for poly in dt_polys:
        box, _ = _order_minarea_box_points(poly.astype(np.int32))
        crop = _rotate_crop_image(img, np.array(box))
        if crop is not None and crop.size > 0 and crop.shape[0] > 0 and crop.shape[1] > 0:
            results.append(crop)
        else:
            results.append(None)
    return results


# ============================================================
# 识别预处理
# ============================================================


class RecPreProcess:
    """识别预处理：固定高48、动态宽 → [-1,1]归一化 → batch右pad"""

    def __init__(self, rec_image_shape: Tuple[int, int, int] = (3, 48, 320)) -> None:
        self._c, self._h, self._w_min = rec_image_shape
        self._max_w = 3200

    def _resize_norm(self, img: np.ndarray, max_wh_ratio: float) -> np.ndarray:
        target_w = int(self._h * max_wh_ratio)
        if target_w > self._max_w:
            resized = cv2.resize(img, (self._max_w, self._h))
            actual_w = self._max_w
            target_w = self._max_w
        else:
            h, w = img.shape[:2]
            if h < 1:
                raise InputError("Recognition crop has zero height — invalid text region")
            actual_w = min(int(math.ceil(self._h * w / float(h))), target_w)
            resized = cv2.resize(img, (actual_w, self._h))
        if resized.ndim == 2:
            raise InputError("Recognition crop is grayscale — expected BGR image")
        chw = np.transpose(resized.astype(np.float32, copy=False), (2, 0, 1))
        chw *= 1.0 / 255.0
        chw = (chw - 0.5) / 0.5
        padded = np.zeros((self._c, self._h, target_w), dtype=np.float32)
        padded[:, :, :actual_w] = chw
        return padded

    def __call__(self, imgs: List[np.ndarray]) -> np.ndarray:
        if not imgs:
            raise InputError("RecPreProcess received empty image list")
        resized = []
        for i, img in enumerate(imgs):
            if not isinstance(img, np.ndarray):
                raise InputError(f"RecPreProcess: item {i} is not a numpy array")
            if img.shape[0] < 1:
                raise InputError(f"RecPreProcess: item {i} has zero height")
            max_ratio = max(self._w_min / self._h, img.shape[1] / float(img.shape[0]))
            resized.append(self._resize_norm(img, max_ratio))
        max_w = max(r.shape[2] for r in resized)
        padded = []
        for r in resized:
            pad = max_w - r.shape[2]
            if pad > 0:
                r = np.pad(r, ((0, 0), (0, 0), (0, pad)), mode="constant", constant_values=0)
            padded.append(r)
        return np.stack(padded, axis=0).astype(np.float32, copy=False)


# ============================================================
# 识别后处理 (CTC)
# ============================================================


class CTCLabelDecode:
    """CTC greedy decode → 去重 → 去blank → 查字典"""

    def __init__(self, character_dict_path: str) -> None:
        self._blank = 0
        with open(character_dict_path, encoding="utf-8") as f:
            # 只过滤真正的空行（\r\n 去掉后为空），保留空格、tab 等有效字符
            raw = tuple(
                line.rstrip("\n\r") for line in f
                if line.rstrip("\n\r") != ""
            )
        if not raw:
            raise PPOCRv6Error(
                f"Character dictionary '{character_dict_path}' is empty"
            )
        self._chars: Tuple[str, ...] = ("blank", *raw)
        self._vocab_size = len(self._chars)

    @property
    def vocab_size(self) -> int:
        return self._vocab_size

    def __call__(self, model_output: np.ndarray) -> Tuple[List[str], List[float]]:
        output = np.asarray(model_output)
        if output.ndim != 3:
            raise InputError(
                f"Recognition model output must be 3D (batch, timesteps, vocab), "
                f"got shape {output.shape}"
            )
        if output.shape[-1] != self._vocab_size:
            raise PPOCRv6Error(
                f"Model vocabulary size mismatch: model outputs {output.shape[-1]} "
                f"classes but dictionary has {self._vocab_size} entries "
                f"(including blank). Check that rec_char_dict_path matches the "
                f"recognition model."
            )
        indices = output.argmax(axis=-1)
        probs = output.max(axis=-1)
        texts, scores = [], []
        for b in range(len(indices)):
            seq = indices[b]
            keep = np.ones(len(seq), dtype=bool)
            keep[1:] = seq[1:] != seq[:-1]
            keep &= seq != self._blank
            # 安全查字典：越界索引映射到 blank / 跳过
            safe_indices = np.where(keep & (seq < self._vocab_size), seq, self._blank)
            safe_keep = (safe_indices != self._blank) & keep
            text = "".join(self._chars[idx] for idx in safe_indices[safe_keep])
            score = float(probs[b][keep].mean()) if keep.any() else 0.0
            texts.append(text)
            scores.append(score)
        return texts, scores


# ============================================================
# 主推理器
# ============================================================


class PPOCRv6:
    """PP-OCRv6 纯 ONNX Runtime 推理器。

    Usage::

        from ppocrv6_onnx import PPOCRv6

        # 使用内置模型（最简单）
        ocr = PPOCRv6()
        results = ocr(image_bgr)
        for r in results:
            print(r.text, r.score, r.box)

        # 使用自定义模型
        ocr = PPOCRv6("det.onnx", "rec.onnx", "dict.txt")
        ocr.close()
    """

    # 内置数据目录（包内 data/ 子目录）
    _BUNDLED_DATA = Path(__file__).parent / "data"

    def __init__(
        self,
        det_model_path: Optional[str] = None,
        rec_model_path: Optional[str] = None,
        rec_char_dict_path: Optional[str] = None,
        *,
        det_thresh: float = 0.3,
        det_box_thresh: float = 0.6,
        det_unclip_ratio: float = 1.5,
        rec_batch_size: int = 6,
        prefer_accelerator: bool = False,
    ) -> None:
        # 未指定路径时使用内置模型
        _data = self._BUNDLED_DATA
        det_model_path = det_model_path or str(_data / "det.onnx")
        rec_model_path = rec_model_path or str(_data / "rec.onnx")
        rec_char_dict_path = rec_char_dict_path or str(_data / "chars.txt")

        # 校验文件
        for path, name in [(det_model_path, "det_model"),
                           (rec_model_path, "rec_model"),
                           (rec_char_dict_path, "dict")]:
            if not Path(path).is_file():
                raise FileNotFoundError(f"{name}: {path}")

        # providers: 默认 CPU，可选 CoreML/CUDA（均保留 CPU 后备）
        if prefer_accelerator:
            available = ort.get_available_providers()
            gpu = next((p for p in ("CoreMLExecutionProvider",
                                     "CUDAExecutionProvider") if p in available), None)
            providers = [gpu, "CPUExecutionProvider"] if gpu else ["CPUExecutionProvider"]
        else:
            providers = ["CPUExecutionProvider"]

        try:
            self._det_sess = ort.InferenceSession(det_model_path, providers=providers)
        except Exception as e:
            raise ModelLoadError(
                f"Failed to load detection model '{det_model_path}': {e}"
            ) from e

        try:
            self._rec_sess = ort.InferenceSession(rec_model_path, providers=providers)
        except Exception as e:
            self._det_sess = None  # 清理已加载的检测模型
            raise ModelLoadError(
                f"Failed to load recognition model '{rec_model_path}': {e}"
            ) from e

        try:
            det_inputs = self._det_sess.get_inputs()
            rec_inputs = self._rec_sess.get_inputs()
            if not det_inputs or not rec_inputs:
                raise ModelLoadError("ONNX model has no inputs — check model file")
            self._det_input = det_inputs[0].name
            self._rec_input = rec_inputs[0].name
        except ModelLoadError:
            raise
        except Exception as e:
            self._det_sess = None
            self._rec_sess = None
            raise ModelLoadError(f"Failed to inspect ONNX model inputs: {e}") from e

        self._det_pre = DetPreProcess()
        self._det_post = DBPostProcess(thresh=det_thresh, box_thresh=det_box_thresh,
                                       unclip_ratio=det_unclip_ratio)
        self._rec_pre = RecPreProcess()
        self._rec_post = CTCLabelDecode(rec_char_dict_path)
        self._rec_bs = rec_batch_size
        self._closed = False

    # ── 资源管理 ──

    def close(self) -> None:
        """释放 ONNX session 资源。多次调用安全。"""
        if not self._closed:
            try:
                if self._det_sess is not None:
                    self._det_sess = None
                if self._rec_sess is not None:
                    self._rec_sess = None
            finally:
                self._closed = True

    def __enter__(self) -> "PPOCRv6":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass  # 解释器关闭阶段任何错误都忽略

    # ── 推理 API ──

    def _check_open(self) -> None:
        if self._closed:
            raise RuntimeError("PPOCRv6 has been closed")

    def detect(self, img_bgr: np.ndarray) -> Tuple[np.ndarray, List[float]]:
        """文本检测。返回 (boxes[N,4,2], scores[N])"""
        self._check_open()
        x, shape = self._det_pre(img_bgr)
        outputs = self._det_sess.run(None, {self._det_input: x})
        return self._det_post(outputs[0], shape)

    def recognize(self, img_list: List[np.ndarray]) -> Tuple[List[str], List[float]]:
        """批量文本识别。返回 (texts, scores)"""
        self._check_open()
        n = len(img_list)
        if n == 0:
            return [], []

        # 按宽高比排序减少 batch padding
        order = [i for i, _ in sorted(
            enumerate(img_list), key=lambda x: x[1].shape[1] / float(x[1].shape[0]))]
        sorted_imgs = [img_list[i] for i in order]

        texts: List[Optional[str]] = [None] * n
        scores: List[Optional[float]] = [None] * n

        for start in range(0, n, self._rec_bs):
            batch = sorted_imgs[start:start + self._rec_bs]
            x = self._rec_pre(batch)
            outputs = self._rec_sess.run(None, {self._rec_input: x})
            t, s = self._rec_post(outputs[0])
            for j, (text, score) in enumerate(zip(t, s)):
                orig = order[start + j]
                texts[orig] = text
                scores[orig] = score

        return ([t or "" for t in texts], [s or 0.0 for s in scores])

    def __call__(self, img_bgr: np.ndarray) -> List[OCRResult]:
        """完整 OCR：检测 → 排序 → 裁剪 → 识别"""
        self._check_open()
        DetPreProcess._validate_image(img_bgr)
        boxes, _ = self.detect(img_bgr)
        if len(boxes) == 0:
            return []

        sorted_boxes = sort_quad_boxes(boxes)
        crops = crop_by_polys(img_bgr, sorted_boxes)

        valid_boxes, valid_crops = [], []
        for box, crop in zip(sorted_boxes, crops):
            if crop is not None:
                valid_boxes.append(box)
                valid_crops.append(crop)

        if not valid_crops:
            return []

        texts, scores = self.recognize(valid_crops)
        return [OCRResult(text=t, score=s, box=b.tolist())
                for t, s, b in zip(texts, scores, valid_boxes)]
